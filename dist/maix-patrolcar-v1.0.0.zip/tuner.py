# tuner.py
import time, os, json
from maix import image
import vision 

# 存储路径
THRESH_FILE = "/data/my_thresholds.json"   

# 阈值数组索引定义: [0:L_MIN, 1:L_MAX, 2:A_MIN, 3:A_MAX, 4:B_MIN, 5:B_MAX]
# L (Lightness): 亮度，0=纯黑，100=纯白
# A (Green-Red): 绿红轴，负值越小越绿，正值越大越红
# B (Blue-Yellow): 蓝黄轴，负值越小越蓝，正值越大越黄

PC_THRESHOLDS = {
    "black": [0, 30, -20, 20, -20, 20],  
    "blue":  [15, 45, -20, 110, -128, -70], 
    "red":   [30, 60, 50, 127, 10, 100],     
    "green": [40, 75, -128, -30, 10, 100]
}
current_thresholds = {}

# UI 布局 - 最终优化版
UI_BTNS = {
    "target": {"x": 10,  "y": 10,  "w": 100, "h": 60, "color": image.COLOR_BLUE,  "text": ""},
    "plus":   {"x": 10,  "y": 80,  "w": 100, "h": 60, "color": image.COLOR_GREEN, "text": "+ 5"},
    "minus":  {"x": 10,  "y": 150, "w": 100, "h": 60, "color": image.COLOR_RED,   "text": "- 5"},
    
    "save":   {"x": 10,  "y": 410, "w": 110, "h": 60, "color": image.COLOR_BLUE,  "text": "SAVE"},
    "reset":  {"x": 130, "y": 410, "w": 110, "h": 60, "color": image.COLOR_GRAY,  "text": "RESET"}, 
    "start":  {"x": 250, "y": 410, "w": 160, "h": 60, "color": image.COLOR_GREEN, "text": "START"}
}

PARAM_BTNS = []
_params_names = ["L_MIN", "L_MAX", "A_MIN", "A_MAX", "B_MIN", "B_MAX"]
for i, name in enumerate(_params_names):
    # 右侧参数宽度 120
    btn = {"x": 515, "y": 2 + i * 80, "w": 120, "h": 76, "color": image.COLOR_GRAY, "text": name}
    PARAM_BTNS.append(btn)

_targets = ["black", "red", "blue", "green"] 
_target_idx = 0                              
_param_idx = 0 
_last_touch_time = 0 

def draw_button(img, btn, text_override=None, is_active=False, text_scale=1.2):
    # 1. 绘制方框
    border_color = image.COLOR_WHITE if is_active else btn["color"]
    border_thick = 5 if is_active else 2 
    img.draw_rect(btn["x"], btn["y"], btn["w"], btn["h"], border_color, thickness=border_thick)
    img.draw_rect(btn["x"]+2, btn["y"]+2, btn["w"]-4, btn["h"]-4, btn["color"], thickness=-1) 
    
    # 2. 准备文字
    txt = text_override if text_override else btn["text"]
    text_color = image.COLOR_YELLOW if is_active else image.COLOR_WHITE
    font_thick = 2 
    
    # 3. 🌟 【已修正】调用 string_size 获取文字宽高实现自动居中
    tw, th = image.string_size(txt, scale=text_scale, thickness=font_thick)
    
    # 计算完美的居中起始坐标
    tx = btn["x"] + (btn["w"] - tw) // 2
    ty = btn["y"] + (btn["h"] - th) // 2
    
    # 4. 绘制文字
    img.draw_string(tx, ty, txt, text_color, scale=text_scale, thickness=font_thick)

def is_point_in_btn(px, py, btn):
    return btn["x"] <= px <= btn["x"] + btn["w"] and btn["y"] <= py <= btn["y"] + btn["h"]

def get_default_thresholds():
    return {k: list(v) for k, v in PC_THRESHOLDS.items()}

def load_thresholds():
    global current_thresholds 
    if os.path.exists(THRESH_FILE): 
        try:
            with open(THRESH_FILE, "r") as f:
                current_thresholds = json.load(f) 
            return
        except Exception: pass
    current_thresholds = get_default_thresholds()

def save_thresholds():
    dir_name = os.path.dirname(THRESH_FILE)
    if dir_name and not os.path.exists(dir_name): os.makedirs(dir_name)
    with open(THRESH_FILE, "w") as f:
        json.dump(current_thresholds, f) 

def run_setup_ui(img, ts, disp):
    global _target_idx, _param_idx, _last_touch_time, current_thresholds
    current_target = _targets[_target_idx]
    vision.draw_preview(img, current_target, current_thresholds) 
    
    # 绘制左侧控制栏
    draw_button(img, UI_BTNS["target"], f"{current_target}", text_scale=1.5)
    draw_button(img, UI_BTNS["plus"], text_scale=2.0)
    draw_button(img, UI_BTNS["minus"], text_scale=2.0)
    
    # 绘制底部操作栏
    draw_button(img, UI_BTNS["save"], text_scale=1.5)
    draw_button(img, UI_BTNS["reset"], text_scale=1.5)
    draw_button(img, UI_BTNS["start"], text_scale=1.5) 
    
    # 绘制右侧 6 个参数列表
    for i, btn in enumerate(PARAM_BTNS):
        param_name = _params_names[i]
        val = current_thresholds[current_target][i] 
        is_active = (i == _param_idx)
        draw_button(img, btn, f"{param_name}:{val}", is_active, text_scale=1.2)
    
    # 处理屏幕触摸
    touch_data = ts.read()
    if touch_data and len(touch_data) >= 3 and touch_data[2] == 1: 
        tx, ty = touch_data[0], touch_data[1]
        current_time = time.time()
        if (current_time - _last_touch_time) > 0.2: 
            _last_touch_time = current_time
            if is_point_in_btn(tx, ty, UI_BTNS["target"]):
                _target_idx = (_target_idx + 1) % len(_targets) 
            elif is_point_in_btn(tx, ty, UI_BTNS["minus"]):
                current_val = current_thresholds[current_target][_param_idx]
                current_thresholds[current_target][_param_idx] = max(-128, current_val - 5)
            elif is_point_in_btn(tx, ty, UI_BTNS["plus"]):
                current_val = current_thresholds[current_target][_param_idx]
                current_thresholds[current_target][_param_idx] = min(127, current_val + 5)
            elif is_point_in_btn(tx, ty, UI_BTNS["reset"]):
                current_thresholds = get_default_thresholds() 
                img.draw_string(200, 200, "RESET OK!", image.COLOR_YELLOW, scale=4, thickness=2)
                disp.show(img)
                time.sleep(0.5)
            elif is_point_in_btn(tx, ty, UI_BTNS["save"]):
                save_thresholds() 
                img.draw_string(280, 415, "SAVED!", image.COLOR_RED, scale=3, thickness=2)
                disp.show(img)
                time.sleep(0.5)  
            elif is_point_in_btn(tx, ty, UI_BTNS["start"]):
                return True 
                
            for i, btn in enumerate(PARAM_BTNS):
                if is_point_in_btn(tx, ty, btn):
                    _param_idx = i 
                    break
    return False