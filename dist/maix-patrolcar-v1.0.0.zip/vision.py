# vision.py (完整覆盖或追加)
from maix import image

def find_triangle_arrow(img, current_thresholds):
    """
    【新增算法】寻找黑色三角形箭头，并判断朝向（远离或朝向）
    """
    # 提取黑色阈值 (底层会在内存中对这组阈值进行二值化处理)
    thresh = [current_thresholds["black"]]
    # 过滤掉小的噪点，必须是比较大的黑块
    blobs = img.find_blobs(thresh, pixels_threshold=1000) 
    
    if blobs:
        # 挑选面积最大的黑块
        arrow_blob = max(blobs, key=lambda b: b[2] * b[3])
        x, y, w, h = arrow_blob[0], arrow_blob[1], arrow_blob[2], arrow_blob[3]
        pixels = arrow_blob[4]
        area = w * h
        
        # 1. 形状过滤：判断是不是三角形
        # 方形的填充率通常大于 0.8，三角形因为少了一半，通常在 0.45 ~ 0.65 之间
        fill_ratio = pixels / area if area > 0 else 0
        
        if fill_ratio < 0.75: # 剔除方形黑块，锁定三角形
            # 2. 获取物理重心(质心)与外接矩形的几何中心
            mass_cx, mass_cy = arrow_blob[5], arrow_blob[6] 
            box_cx, box_cy = x + w // 2, y + h // 2 
            
            # 计算重心的垂直偏移量
            dy = mass_cy - box_cy
            
            direction = "UNKNOWN"
            # 如果重心在下方 (dy > 0)：底座在下，尖端朝上 => 远离摄像头
            if dy > 5:
                direction = "AWAY"
            # 如果重心在上方 (dy < 0)：底座在上，尖端朝下 => 朝向摄像头
            elif dy < -5:
                direction = "TOWARDS"
                
            # 绘制视觉反馈（黄框和红色的重心十字）
            img.draw_rect(x, y, w, h, image.COLOR_YELLOW, thickness=2)
            img.draw_cross(mass_cx, mass_cy, image.COLOR_RED) 
            img.draw_string(x, max(0, y - 30), f"DIR: {direction}", image.COLOR_YELLOW, scale=2)
            
            return direction
    return None

def identify_markers(img, current_thresholds):
    """巡线模式：基于宽高比和填充率识别颜色和形状"""
    # 注意：这里我们加入了 "black"，防止巡线时遇到黑色图形漏判
    colors_to_check = [ "red", "blue", "green"]
    
    for color in colors_to_check:
        thresh = [current_thresholds[color]]
        blobs = img.find_blobs(thresh, pixels_threshold=400) 
        
        if blobs:
            blob = max(blobs, key=lambda b: b[2] * b[3]) 
            x, y, w, h = blob[0], blob[1], blob[2], blob[3]
            pixels = blob[4]
            
            area = w * h 
            fill_ratio = pixels / area if area > 0 else 0 
            aspect_ratio = w / h if h > 0 else 1          
            
            shape = "unknown"
            if 0.8 < aspect_ratio < 1.2:
                if fill_ratio > 0.85: shape = "square"    
                elif fill_ratio > 0.65: shape = "circle"  
                else: shape = "triangle"                  
            else:
                shape = "triangle" 
            
            img.draw_rect(x, y, w, h, image.COLOR_WHITE, thickness=2)
            img.draw_string(x, max(0, y-20), f"{color}-{shape}", image.COLOR_WHITE, scale=2)
            return {"color": color, "shape": shape}
    return None

def draw_preview(img, target_name, current_thresholds):
    """调参预览辅助"""
    thresh = [current_thresholds[target_name]]
    blobs = img.find_blobs(thresh, pixels_threshold=400)
    if blobs:
        b = max(blobs, key=lambda b: b[2] * b[3])
        img.draw_rect(b[0], b[1], b[2], b[3], image.COLOR_WHITE, thickness=2)