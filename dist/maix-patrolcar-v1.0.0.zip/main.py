# main.py
import time
from maix import app, image, camera, display, uart, touchscreen
import tuner
import vision

TARGET_WIDTH = 640  
TARGET_HEIGHT = 480 

def init_hardware():
    cam = camera.Camera(TARGET_WIDTH, TARGET_HEIGHT)
    cam.skip_frames(10) 
    disp = display.Display()                         
    ts = touchscreen.TouchScreen()                   
    serial_dev = uart.UART("/dev/ttyS0", 115200) 
    return cam, disp, ts, serial_dev

def main():
    cam, disp, ts, serial_dev = init_hardware()
    tuner.load_thresholds() 
    
    state = "SETUP"      
    start_time = 0       
    last_sent_marker = None   
    marker_debounce_count = 0 
    last_frame_time = time.time() 
    touch_hold_start_time = 0 
    
    # 新增：用于记录找箭头的定格时间
    arrow_confirmed = False
    arrow_find_time = 0

    while not app.need_exit():
        img = cam.read() 
        
        # ==========================================
        # 状态 1：调参模式
        # ==========================================
        if state == "SETUP":
            is_start_pressed = tuner.run_setup_ui(img, ts, disp)
            
            if is_start_pressed:
                # 点击 START 后，不急着巡线，先进入找箭头模式
                state = "FIND_ARROW"
                touch_hold_start_time = 0 
                arrow_confirmed = False
                print(">>> 切换到状态: 寻找起始箭头")

        # ==========================================
        # 状态 2：起步找箭头模式
        # ==========================================
        elif state == "FIND_ARROW":
            # 屏幕提示当前状态
            img.draw_string(10, 10, "STEP 1: FINDING ARROW...", image.COLOR_RED, scale=2)
            
            dir_result = vision.find_triangle_arrow(img, tuner.current_thresholds)
            
            if dir_result in ["AWAY", "TOWARDS"]: 
                
                # 如果成功识别到了方向，记录并在屏幕停留 2 秒，方便你观察
                if not arrow_confirmed:
                    arrow_confirmed = True
                    arrow_find_time = time.time()
                    serial_dev.write_str(f"$DIR,{dir_result}\n")
                    print(f"找到箭头! 明确方向: {dir_result}")
                
                # 倒计时 2 秒后进入正式巡线
                elapsed = time.time() - arrow_find_time
                if elapsed > 2.0:
                    state = "PATROLLING"
                    start_time = time.time()
                    arrow_confirmed = False
                    print(">>> 切换到状态: 正式发车巡线")
            else:
                # 没识别到，或者识别结果是 "UNKNOWN"，统统重置状态，死死卡住！
                arrow_confirmed = False
        # ==========================================
        # 状态 3：发车巡线模式
        # ==========================================
        elif state == "PATROLLING":
            elapsed = time.time() - start_time
            img.draw_string(10, 10, f"STEP 2: SCANNING... {elapsed:.1f}s", image.COLOR_GREEN, scale=2)
            
            marker = vision.identify_markers(img, tuner.current_thresholds)
            if marker:
                current_marker_str = f"{marker['color']},{marker['shape']}"
                if current_marker_str == last_sent_marker:
                    marker_debounce_count += 1
                else:
                    last_sent_marker = current_marker_str
                    marker_debounce_count = 1
                
                if marker_debounce_count == 2: 
                    serial_dev.write_str(f"$MARKER,{current_marker_str}\n")
                    print(f"识别结果: {current_marker_str}")
                    marker_debounce_count = -10 

        # ==========================================
        # 全局保护：长按屏幕退回调参模式
        # ==========================================
        if state in ["FIND_ARROW", "PATROLLING"]:
            touch_data = ts.read()
            if touch_data and len(touch_data) >= 3 and touch_data[2] == 1:
                if touch_hold_start_time == 0:
                    touch_hold_start_time = time.time()
                elif time.time() - touch_hold_start_time > 1.5:
                    img.draw_rect(0, 0, TARGET_WIDTH, TARGET_HEIGHT, image.COLOR_BLACK, thickness=-1)
                    img.draw_string(150, 200, "BACK TO SETUP...", image.COLOR_YELLOW, scale=3)
                    disp.show(img)
                    print(">>> 强制退出，返回调参模式")
                    time.sleep(0.5) 
                    
                    state = "SETUP"
                    touch_hold_start_time = 0
                    last_sent_marker = None
                    marker_debounce_count = 0
                    arrow_confirmed = False
            else:
                touch_hold_start_time = 0

        # ==========================================
        # 帧率与统一刷新
        # ==========================================
        current_time = time.time()
        delta_t = current_time - last_frame_time 
        fps = 1.0 / delta_t if delta_t > 0 else 0
        last_frame_time = current_time
        
        img.draw_string(500, 10, f"FPS:{fps:.1f}", image.COLOR_WHITE, scale=2)
        disp.show(img)

if __name__ == "__main__":
    main()